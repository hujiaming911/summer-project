package com.wireless.uf.myapplication;

import android.content.AbstractThreadedSyncAdapter;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.IOException;
import java.net.Socket;
import java.util.Enumeration;
import java.net.NetworkInterface;
import java.net.InterfaceAddress;


public class MainActivity extends AppCompatActivity implements SensorEventListener{
    RelativeLayout relativelayout2;

    Button button;
    TextView textView;
    SensorValues sensorValues;
    SensorSocketThread socketThread;

    private SensorManager sensorManager;
    private TextView accelerationView;
    private TextView gyroscopeView;
    private TextView magneticSensorView;
    private TextView accelerationViewvalue;
    private TextView gyroscopeViewvalue;
    private TextView magneticSensorViewvalue;
    private long lastUpdate;
    private float[]  gravity    = new float[]{ 0, 0, 0 };
    private boolean threadStarted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        relativelayout2= findViewById(R.id.relative2);
        accelerationView = findViewById(R.id.textView1);
        gyroscopeView = findViewById(R.id.textView2);
        magneticSensorView = findViewById(R.id.textView3);
        accelerationViewvalue = findViewById(R.id.textView1value);
        gyroscopeViewvalue = findViewById(R.id.textView2value);
        magneticSensorViewvalue = findViewById(R.id.textView3value);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorValues = new SensorValues();
        lastUpdate = System.currentTimeMillis();

        button = findViewById(R.id.button);
        textView = findViewById(R.id.text_view);

        findViewById(R.id.button).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if(button.getText()=="close"){
                    wifi.setWifiEnabled(false);
                    textView.setText("  WiFi is close");
                    button.setText("Send Beacon");
                    relativelayout2.setBackgroundResource(R.color.white);
                }
                else{
                    wifi.setWifiEnabled(true);
                    textView.setText("  WiFi is on");
                    button.setText("close");
                    relativelayout2.setBackgroundResource(R.color.green);
                    try {
                        Thread.sleep(5000); // Wait for Wifi to turn on
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Log.i("MAIN ACTIVITY","Starting thread");
                    threadStarted = true;
                    socketThread = new SensorSocketThread();
                    socketThread.start();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.exit){
            finish();
        }
        else if(item.getItemId()==R.id.about){
            Toast.makeText(MainActivity.this,"to be continued",Toast.LENGTH_LONG).show();
        }
        return true;
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        if(sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE){
            getGyroscope(sensorEvent);
        }
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            getAccelerometer(sensorEvent);
        }
        if(sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
            getMagneticField(sensorEvent);
        }
    }

    private void getAccelerometer(SensorEvent event) {
        float[] values = event.values;
        float x = values[0];
        float y = values[1];
        float z = values[2];

        // if(Settings.ACCLOWPASS) { // low pass filter
        final float alpha = (float) 0.8;
        gravity[0] = alpha * gravity[0] + (1 - alpha) * values[0];
        gravity[1] = alpha * gravity[1] + (1 - alpha) * values[1];
        gravity[2] = alpha * gravity[2] + (1 - alpha) * values[2];

        x = values[0] - gravity[0];
        y = values[1] - gravity[1];
        z = values[2] - gravity[2];
        //}

        long actualTime = event.timestamp;
        if (actualTime - lastUpdate < 1000) {
            return;
        }
        lastUpdate = actualTime;
        accelerationViewvalue.setText(" x: "+x+" y: "+y+" z:"+z);
        if(threadStarted){

            Message messageToThread = new Message();
            Bundle messageData = new Bundle();
            messageToThread.what = 1;
            messageData.putFloat("accX", x);
            messageData.putFloat("accY", y);
            messageData.putFloat("accZ", z);
            messageToThread.setData(messageData);
            Log.i("MAIN ACTIVITY","Accelerometer sensor data sent");
            socketThread.getHandler().sendMessage(messageToThread);
        }
    }

    private void getGyroscope(SensorEvent event){

        float[] values = event.values;
        // Movement
        float x = values[0];
        float y = values[1];
        float z = values[2];
        long actualTime = event.timestamp;
        if (actualTime - lastUpdate < 1000) {
            return;
        }
        lastUpdate = actualTime;
        gyroscopeViewvalue.setText(" x: "+x+" y: "+y+" z:"+z);
        if(threadStarted){

            Message messageToThread = new Message();
            Bundle messageData = new Bundle();
            messageToThread.what = 2;
            messageData.putFloat("gyroX", x);
            messageData.putFloat("gryoY", y);
            messageData.putFloat("gryoZ", z);
            messageToThread.setData(messageData);
            Log.i("MAIN ACTIVITY","Gyroscope sensor data sent");
            socketThread.getHandler().sendMessage(messageToThread);
        }
    }

    private void getMagneticField(SensorEvent event){

        float[] values = event.values;
        // Movement
        float x = values[0];
        float y = values[1];
        float z = values[2];
        long actualTime = event.timestamp;
        if (actualTime - lastUpdate < 1000) {
            return;
        }
        lastUpdate = actualTime;
        magneticSensorViewvalue.setText(" x: "+x+" y: "+y+" z:"+z);
        if(threadStarted){

            Message messageToThread = new Message();
            Bundle messageData = new Bundle();
            messageToThread.what = 3;
            messageData.putFloat("magX", x);
            messageData.putFloat("magY", y);
            messageData.putFloat("magZ", z);
            messageToThread.setData(messageData);
            Log.i("MAIN ACTIVITY","Magnetic sensor data sent");
            socketThread.getHandler().sendMessage(messageToThread);
        }
     }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        // register this class as a listener for the orientation and
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        // unregister listener
        super.onPause();
        sensorManager.unregisterListener(this);
    }
}
