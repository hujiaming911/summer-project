package com.wireless.uf.myapplication;

import android.util.Log;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

public class UDPThread implements Runnable{

    DatagramSocket ds;
    private static long SLEEP_TIME = 30000;

    public UDPThread(DatagramSocket ds){

        this.ds = ds;
    }

    @Override
    public void run() {

        try {

            while(true) {

                byte[] sendData = "DISCOVER_UDPSERVER_REQUEST".getBytes();
                Log.i("SensorSocketThread", "Before UDP Broadcast");

                // Broadcast the message over all the network interfaces
                Enumeration interfaces = NetworkInterface.getNetworkInterfaces();
                while (interfaces.hasMoreElements()) {
                    NetworkInterface networkInterface = (NetworkInterface) interfaces.nextElement();

                    if (networkInterface.isLoopback() || !networkInterface.isUp()) {

                        continue; // Don't want to broadcast to the loopback interface
                    }

                    for (InterfaceAddress interfaceAddress : networkInterface.getInterfaceAddresses()) {
                        InetAddress broadcast = interfaceAddress.getBroadcast();
                        if (broadcast == null) {
                            continue;
                        }
                        try {
                            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, broadcast, 8888);
                            ds.send(sendPacket);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                Thread.sleep(SLEEP_TIME);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        Log.i("SensorSocketThread","After broadcast");
    }
}
