package com.wireless.uf.myapplication;

import android.util.Log;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class TCPThread implements Runnable{

    Socket s;
    PrintWriter pw;
    SensorValues sensorValues;

    public TCPThread(Socket s, PrintWriter pw, SensorValues sensorValues){

        this.s = s;
        this.pw = pw;
        this.sensorValues = sensorValues;
    }

    @Override
    public void run() {
        try {

            while(true) {
                pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
                StringBuilder sb = new StringBuilder();
                sb.append(" AccX " + String.valueOf(sensorValues.getAccX()));
                sb.append(" AccY " + String.valueOf(sensorValues.getAccY()));
                sb.append(" AccZ " + String.valueOf(sensorValues.getAccZ()));
                sb.append(" GyroX " + String.valueOf(sensorValues.getGyroX()));
                sb.append(" GyroY " + String.valueOf(sensorValues.getGyroY()));
                sb.append(" GyroZ " + String.valueOf(sensorValues.getGyroZ()));
                sb.append(" MagX " + String.valueOf(sensorValues.getMagX()));
                sb.append(" MagY " + String.valueOf(sensorValues.getMagY()));
                sb.append(" MagZ " + String.valueOf(sensorValues.getMagZ()));
                this.sendMessage(sb.toString());
                Thread.sleep(5000);
            }
        } catch (Exception e) {
            Log.e("SensorSocketThread","Socket Exception", e);
            e.printStackTrace();
        }finally {
            pw.flush();
            pw.close();
            try {
                s.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Log.i("SensorSocketThread","SOCKET CLOSED");
        }
    }

    public void sendMessage(String message){
        if (pw != null && !pw.checkError()) {
            pw.println(message);
            pw.flush();
            Log.i("SensorSocketThread", "Sent Message: " + message);

        }
    }
}
