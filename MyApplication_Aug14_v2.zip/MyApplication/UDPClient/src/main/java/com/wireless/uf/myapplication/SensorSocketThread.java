package com.wireless.uf.myapplication;

import android.os.Message;
import android.util.Log;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashSet;

import android.os.Handler;

public class SensorSocketThread extends Thread {

    PrintWriter out;
    UDPThread udpThread;
    SensorValues sensorValues = new SensorValues();

    private Handler socketHandler = new Handler() {
        public void handleMessage(Message msg){
            Log.i("SensorSocketThread", "Socket Handler received sensor data");
            if(msg.what==1){
                sensorValues.setAccX(msg.getData().getFloat("accX"));
                sensorValues.setAccY(msg.getData().getFloat("accY"));
                sensorValues.setAccZ(msg.getData().getFloat("accZ"));
            }else if(msg.what==2){
                sensorValues.setGyroX(msg.getData().getFloat("gyroX"));
                sensorValues.setGyroY(msg.getData().getFloat("gyroY"));
                sensorValues.setGyroZ(msg.getData().getFloat("gyroZ"));
            }else if(msg.what==3){
                sensorValues.setMagX(msg.getData().getFloat("magX"));
                sensorValues.setMagY(msg.getData().getFloat("magY"));
                sensorValues.setMagZ(msg.getData().getFloat("magZ"));
            }
        }
    };

    @Override
    public void run() {

        DatagramSocket ds = null;

        try {

            ds = new DatagramSocket();
            ds.setBroadcast(true);
            udpThread = new UDPThread(ds);
            Thread t = new Thread(udpThread);
            t.start();

            byte[] recvBuf = new byte[15000];
            HashSet<String> addressSet = new HashSet<>();
            Collections.synchronizedSet(addressSet);
            while(true) {

                DatagramPacket receivePacket = new DatagramPacket(recvBuf, recvBuf.length);
                ds.receive(receivePacket);

                String message = new String(receivePacket.getData()).trim();
                if (message.equals("UDPSERVER_RESPONSE")) {

                    Log.i("SensorSocketThread", "UDP Response Received");
                    String output = receivePacket.getAddress().toString();
                    synchronized (addressSet) {
                        if(!addressSet.contains(output)) {
                            addressSet.add(output);
                            Socket s = new Socket(receivePacket.getAddress().getHostAddress(), 8848);
                            TCPThread tcpThread = new TCPThread(s,out,sensorValues);
                            Thread t1 = new Thread(tcpThread);
                            t1.start();
                        }
                    }
                }
            }//Close the port!
            //ds.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }finally {
            ds.close();
        }
    }

    public Handler getHandler() {
        return socketHandler;
    }
}
