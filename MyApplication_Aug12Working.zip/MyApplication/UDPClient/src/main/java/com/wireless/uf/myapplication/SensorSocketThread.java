package com.wireless.uf.myapplication;

import android.os.Message;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.Enumeration;
import android.os.Handler;
import java.util.logging.LogRecord;

public class SensorSocketThread extends Thread {

    SensorValues sensorObj = new SensorValues();

    private Handler socketHandler = new Handler() {
        public void handleMessage(Message msg){
            if(msg.what==0){
                sensorObj.setAccX(msg.getData().getFloat("accX"));
                sensorObj.setAccY(msg.getData().getFloat("accY"));
                sensorObj.setAccZ(msg.getData().getFloat("accZ"));
                sensorObj.setGyroX(msg.getData().getFloat("gyroX"));
                sensorObj.setGyroY(msg.getData().getFloat("gyroY"));
                sensorObj.setGyroZ(msg.getData().getFloat("gyroZ"));
                sensorObj.setMagX(msg.getData().getFloat("magX"));
                sensorObj.setMagY(msg.getData().getFloat("magY"));
                sensorObj.setMagZ(msg.getData().getFloat("magZ"));
            }
        }
    };

    @Override
    public void run() {

        DatagramSocket c;

        // Find the server using UDP broadcast
        try {
            //Open a random port to send the package
            c = new DatagramSocket();
            c.setBroadcast(true);

            byte[] sendData = "DISCOVER_FUIFSERVER_REQUEST".getBytes();
            Log.i("UDP Broadcast","Before UDP Broadcast");
            //Try the 255.255.255.255 first
            try {
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName("255.255.255.255"), 8888);
                c.send(sendPacket);
                System.out.println(getClass().getName() + ">>> Request packet sent to: 255.255.255.255 (DEFAULT)");
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Broadcast the message over all the network interfaces
            Enumeration interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface networkInterface = (NetworkInterface) interfaces.nextElement();

                if (networkInterface.isLoopback() || !networkInterface.isUp()) {
                    //回送接口或者接口没开启就下一个网络接口
                    continue; // Don't want to broadcast to the loopback interface
                }

                for (InterfaceAddress interfaceAddress : networkInterface.getInterfaceAddresses()) {
                    InetAddress broadcast = interfaceAddress.getBroadcast();
                    if (broadcast == null) {
                        continue;
                    }

                    // Send the broadcast package!
                    try {
                        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, broadcast, 8888);
                        c.send(sendPacket);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    System.out.println(getClass().getName() + ">>> Request packet sent to: " + broadcast.getHostAddress() + "; Interface: " + networkInterface.getDisplayName());
                }
            }
            Log.i("UDP Waiting","After broadcast");
            System.out.println(getClass().getName() + ">>> Done looping over all network interfaces. Now waiting for a reply!");

            //Wait for a response
            byte[] recvBuf = new byte[15000];
            DatagramPacket receivePacket = new DatagramPacket(recvBuf, recvBuf.length);
            c.receive(receivePacket);

            //We have a response
            System.out.println(getClass().getName() + ">>> Broadcast response from server: " + receivePacket.getAddress().getHostAddress());

            //Check if the message is correct
            String message = new String(receivePacket.getData()).trim();
            if (message.equals("DISCOVER_FUIFSERVER_RESPONSE")) {
                //DO SOMETHING WITH THE SERVER'S IP (for example, store it in your controller)
                //Controller_Base.setServerIp(receivePacket.getAddress());
                System.out.println("ServerIp: "+receivePacket.getAddress());
                Log.i("UDP Resp","After receiving server ip "+receivePacket.getAddress());
                //Message msg=new Message();
                String output=receivePacket.getAddress().toString();
                //msg.obj=output;
                //handler.sendMessage(msg);
                Log.i("TCP Message","Sending TCP Sample data");
                Socket s = new Socket(receivePacket.getAddress().getHostAddress(), 8848);

                try {
                    while(true) {

                        OutputStream os = s.getOutputStream();
                        StringBuilder sb = new StringBuilder();
                        sb.append(" AccX " + String.valueOf(sensorObj.getAccX()));
                        sb.append(" AccY " + String.valueOf(sensorObj.getAccY()));
                        sb.append(" AccZ " + String.valueOf(sensorObj.getAccZ()));
                        sb.append(" GyroX " + String.valueOf(sensorObj.getGyroX()));
                        sb.append(" GyroY " + String.valueOf(sensorObj.getGyroY()));
                        sb.append(" GyroZ " + String.valueOf(sensorObj.getGyroZ()));
                        sb.append(" MagX " + String.valueOf(sensorObj.getMagX()));
                        sb.append(" MagY " + String.valueOf(sensorObj.getMagY()));
                        sb.append(" MagZ " + String.valueOf(sensorObj.getMagZ()));
                        os.write(sb.toString().getBytes());
                        os.flush();
                        os.close();
                        Thread.sleep(5000);
                    }
                } catch (Exception e) {
                        e.printStackTrace();
                }finally {
                        s.close();
                }
            }                    //Close the port!
            c.close();
        } catch (IOException ex) {
            ex.printStackTrace();
            //Logger.getLogger(LoginWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Handler getHandler() {
        return socketHandler;
    }
}
