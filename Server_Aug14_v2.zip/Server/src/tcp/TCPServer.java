package tcp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServer implements Runnable{

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TCPServer tcp= new TCPServer();
		    Thread thread1=new Thread(tcp);
		    thread1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			ServerSocket ss=new ServerSocket(8848);
			System.out.println("TCP Server listening for data");
			
			while(true){
			
				Socket s=ss.accept();
				System.out.println("Received data");
				BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
				ClientHandler clientHandler = new ClientHandler(s, br, s.getInetAddress().toString());
				Thread t = new Thread(clientHandler);
				t.start();
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}	
}

