package tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.Socket;

public class ClientHandler implements Runnable{

	private Socket s;
	private BufferedReader br;
	private String ipaddress;
	
	public ClientHandler(Socket s, BufferedReader br, String ipaddress) {
		// TODO Auto-generated constructor stub
		this.s = s;
		this.br = br;
		this.ipaddress = ipaddress;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		String info=null;
		while(true){
			System.out.println("Waiting");
			try {
				info = br.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Client: "+ s.getInetAddress().toString() + " : " + info);
        }
	}

	
}
